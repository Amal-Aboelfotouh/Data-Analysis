import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import matplotlib
data = pd.read_csv('Unemployment in India.csv')


data.isnull().sum()
data.drop_duplicates(inplace=True)
data.columns = data.columns.str.strip()

data['Date'] = pd.to_datetime(data['Date'], dayfirst=True)
print(data.dtypes)
print(data.columns)
data['Year'] = data['Date'].dt.year
data['Month'] = data['Date'].dt.month
print(data['Year'])
print(data['Month'])
print(data.info())




if 'Area' in data.columns:
    print("\nArea column:")
    print(data['Area'])
else:
    print("\n'Area' column not found in the DataFrame.")
if 'Region' in data.columns:
    print("\nRegion column:")
    print(data['Region'])
else:
    print("\n'Region' column not found in the DataFrame.")
if 'Estimated Unemployment Rate (%)' in data.columns:
    print("\nEstimated Unemployment Rate (%) column:")
    print(data['Estimated Unemployment Rate (%)'])
else:
    print("\n'Estimated Unemployment Rate (%)' column not found in the DataFrame.")

# data.to_csv('cleaned_data1.csv', index=False)

# print(data.describe())
# plt.figure(figsize=(10, 6))
# sns.histplot(data['Year'], bins=30, kde=True)  # kde=True adds a kernel density estimate
# plt.title('Distribution of Month Column over the region')
# plt.xlabel('Year')
# plt.ylabel('Frequency')
# plt.show()
# plt.figure(figsize=(10, 6))
# sns.boxplot(x='Region', y='Year', data=data)
# plt.title('Box Plot of Numerical Column by Categorical Column')
# plt.xlabel('Categorical Column')
# plt.ylabel('Numerical Column')
# plt.show()

# plt.figure(figsize=(10, 6))
# sns.scatterplot(x='Estimated Unemployment Rate (%)', y='Year', data=data)
# plt.title('Scatter Plot between Numerical Column 1 and Numerical Column 2')
# plt.xlabel('Numerical Column 1')
# plt.ylabel('Numerical Column 2')
# plt.show()



# sns.set(style="dark")
# fmri = sns.load_dataset("fmri")
# Line plot
# Plot the responses for different\
# events and regions
# sns.lineplot(x="Date",
#              y="Estimated Unemployment Rate (%)",
#              hue="Area",
#              style="Frequency",
#              data=data)
# plt.ylim(0, 100)


# Optionally, you can also set labels and title
# plt.xlabel('Date')
# plt.ylabel('Estimated Unemployment Rate (%)')
# plt.title('Unemployment Rate Over a year')
# plt.show()
# sns.set(style="ticks")

# Loading the dataset
# plt.figure()

# Show the results of a linear regression
# sns.lmplot(x="Estimated Employed ", y="Region", data=data)
# plt.xlabel('Estimated Employed')
# plt.ylabel('Region')
# plt.title('Linear Regression of Estimated Employed vs Your Continuous Variable')
#
#
# plt.show()


#A24857

# Assuming your data is loaded into a DataFrame called 'data'
# Filter data for the specific year, for example, 2020
year = 2019
filtered_data = data[data['Year'] == year]

# Group data by Region and calculate the average unemployment rate
grouped_data = filtered_data.groupby('Region')['Estimated Unemployment Rate (%)'].mean().reset_index()

# Create the bar plot
# plt.figure(figsize=(12, 8))
# sns.barplot(x='Region', y='Estimated Unemployment Rate (%)', data=grouped_data, palette=['#5079b2'])
# plt.title(f'Average Unemployment Rate by Region in {year}')
# plt.xlabel('Region')
# plt.ylabel('Average Unemployment Rate (%)')
# plt.xticks(rotation=45, ha='right', va='top')  # Rotate x-axis labels for better readability
# plt.tight_layout()  # Adjust layout to prevent clipping
# plt.ylim(0, 100)
# plt.show()
print(matplotlib.__version__)
data = data.drop(columns=['Year', 'Month'])
numerical_data = data.select_dtypes(include=['number'])
correlation_matrix = numerical_data.corr()

# Create a heatmap
plt.figure(figsize=(10, 8))
# sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".2f", linewidths=0.5)
# plt.xticks(rotation=5)  # 0 degrees for horizontal labels

# Rotate y-axis labels to vertical
# plt.yticks(rotation=90, fontsize=10, ha='right', va='top')
# y_labels = [label.replace(' ', '\n') for label in numerical_data.columns]  # Add line break between words
# plt.yticks(ticks=range(len(y_labels)), labels=y_labels)  # Set the new y-tick labels
# # Add titles and labels
# plt.title('Correlation Heatmap')
# plt.show()





data['Year'] = data['Date'].dt.year
data_2019 = data[data['Year'] == 2019]

# Create the line plot
plt.figure(figsize=(12, 6))
sns.lineplot(data=data_2019, x='Date', y='Estimated Unemployment Rate (%)', marker='o', color='#A24857')

# Annotate specific points (e.g., the minimum and maximum unemployment rates)
min_rate = data_2019['Estimated Unemployment Rate (%)'].min()
max_rate = data_2019['Estimated Unemployment Rate (%)'].max()
min_date = data_2019.loc[data_2019['Estimated Unemployment Rate (%)'] == min_rate, 'Date'].values[0]
max_date = data_2019.loc[data_2019['Estimated Unemployment Rate (%)'] == max_rate, 'Date'].values[0]

plt.annotate(f'Min: {min_rate}%',
             xy=(min_date, min_rate),
             xytext=(min_date, min_rate + 1),
             arrowprops=dict(facecolor='black', arrowstyle='->'))

plt.annotate(f'Max: {max_rate}%',
             xy=(max_date, max_rate),
             xytext=(max_date, max_rate + 1),
             arrowprops=dict(facecolor='black', arrowstyle='->'))

# Set titles and labels
plt.title('Unemployment Rate in 2019')
plt.xlabel('Date')
plt.ylabel('Estimated Unemployment Rate (%)')
plt.xticks(rotation=45)  # Rotate x-axis labels
plt.tight_layout()  # Adjust layout
plt.grid()  # Add grid
plt.show()


